#include <allegro.h>
#include <cmath>
using namespace std;
#include "Objetos.h"
#include "Funciones.h"

Objeto::Objeto(float _X,float _Y){
    Cx = _X;
    Cy = _Y;
    A=0;
    Vx=0;
    Vy=0;
}
void Objeto::Desplazamiento(){
    Cx += Vx;
    Cy += Vy;
    Limites(Cx,XTAM);
    Limites(Cy,YTAM);
}
void Objeto::Acelerar(){
        float ax=0.0 , ay=-0.2;
        Rotacion(ax,ay,0.0,0.0,A);
        Vx += ax;
        Vy += ay;
}
void Objeto::Rotar(double da){
      A+=da;
}


void Asteroide::Construir(BITMAP *buffer)const{
    for(int i=1;i<x.size();i++){
        line(buffer,Cx+x[i-1],Cy+y[i-1],Cx+x[i],Cy+y[i],0xEAECEE);
    }
    line(buffer,Cx+x.back(),Cy+y.back(),Cx+x[0],Cy+y[0],0xEAECEE);
}

Asteroide::Asteroide():Objeto(0,0){
    Cx = Azar(XTAM);
    while(Cx>XTAM*.3 && Cx<XTAM*.7){
        Cx=Azar(XTAM);
    }

    Cy = Azar(XTAM);
    while(Cy>YTAM*.3 && Cy<YTAM*.7){
        Cy=Azar(YTAM);
    }

    Tamanio=25;
    Vx=Azar(1.0)-0.5;
    Vy=Azar(1.0)-0.5;
    puntos();
}

Asteroide::Asteroide(float _x,float _y,float _tam,float _vx,float _vy):Objeto(_x,_y){
    Tamanio = _tam;
    Vx = _vx;
    Vy = _vy;
    puntos();
}
void Asteroide::puntos(){
    for(int i=0;i<12;i++){
        float _x=0;
        float _y=Tamanio+Azar(Tamanio*0.5)-Tamanio*0.25;
        Rotacion(_x,_y,0,0,30*i);
        x.push_back(_x);
        y.push_back(_y);
    }
}

bool Asteroide::DentroDe(float _x,float _y)const{
    float dx = _x - Cx, dy = _y - Cy;
    return sqrt(dx*dx + dy*dy) < Tamanio;
}

void Asteroide::Explota(list<Asteroide*>&A)const{
    if(Tamanio > 20){
        for(int i=0;i<4;i++){
            float _vx = Vx+Azar(1.0)-0.5;
            float _vy = Vy+Azar(1.0)-0.5;
            A.push_back(new Asteroide(Cx,Cy,25/2,_vx,_vy));
        }
    }
}


void Nave::Vertices(float& X1,float& Y1,
                    float& X2,float& Y2,
                    float& X3,float& Y3,
                    float& X4,float& Y4,
                    float& X5,float& Y5) const{
    X1=Cx-4 ; Y1=Cy+6 ;
    X2=Cx+4 ; Y2=Cy+6 ;

    X3=Cx-6 ; Y3=Cy+8 ;
    X4=Cx+6 ; Y4=Cy+8 ;
    X5=Cx   ; Y5=Cy-12 ;
    Rotacion(X1,Y1,Cx,Cy,A);
    Rotacion(X2,Y2,Cx,Cy,A);
    Rotacion(X3,Y3,Cx,Cy,A);
    Rotacion(X4,Y4,Cx,Cy,A);
    Rotacion(X5,Y5,Cx,Cy,A);

}

void Nave::Construir(BITMAP *buffer)const{
    float X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5;
    Vertices(X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5);
    line(buffer,X1,Y1,X2,Y2,0xEAECEE);
    line(buffer,X3,Y3,X5,Y5,0xEAECEE);
    line(buffer,X4,Y4,X5,Y5,0xEAECEE);
}
bool Nave::Colision(Asteroide*A)const{
    float X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5;
    Vertices(X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5);
    return A->DentroDe(X1,Y1)||
           A->DentroDe(X2,Y2)||
           A->DentroDe(X3,Y3)||
           A->DentroDe(X4,Y4)||
           A->DentroDe(X5,Y5)||
           A->DentroDe((X3+X5)/2,(Y3+Y5)/2)||
           A->DentroDe((X4+X5)/2,(Y4+Y5)/2);
}

void Nave::Reaparicion(float x,float y){
    Cx=x, Cy=y;
    Vx=0, Vy=0;
}

void Nave::Fuego(BITMAP *buffer) const{
    float X6=Cx , Y6=Cy+15;
    float X7=Cx-3 , Y7=Cy+6;
    float X8=Cx+3 , Y8=Cy+6;

    Rotacion(X6,Y6,Cx,Cy,A);
    Rotacion(X7,Y7,Cx,Cy,A);
    Rotacion(X8,Y8,Cx,Cy,A);

    line(buffer,X7,Y7,X6,Y6,0xEAECEE);
    line(buffer,X8,Y8,X6,Y6,0xEAECEE);

}
int Nave::NavesDisponibles(int naves){
    Naves = naves;
    if(Naves==0){
        return 0;
    }else{
        return Naves;
    }
}

int Nave::PuntosDisponibles(int p){
    Puntos = p;
    return Puntos;
}

Proyectil *Nave::Disparo(BITMAP*buffer)const{
    float X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5;
    Vertices(X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5);

    return new Proyectil(X5,Y5,A);
}

Proyectil::Proyectil(float _x,float _y,float _a):Objeto(_x,_y){
    A = _a;
    Vx = 0; Vy = -5;
    Rotacion(Vx,Vy,0,0,A);
}
void Proyectil::Construir(BITMAP *buffer)const{
    float X1= 0 , Y1 = -2;
    float X2= 0 , Y2 = 2;
    Rotacion(X1,Y1,0,0,A);
    Rotacion(X2,Y2,0,0,A);
    line(buffer,X1+Cx,Y1+Cy,X2+Cx,Y2+Cy,0xEAECEE);
}
void Proyectil::Desplazamiento(){
    Cx += Vx;
    Cy += Vy;
}
bool Proyectil::Fuera()const{
    return Cx > XTAM || Cx < 0 || Cy > YTAM || Cy < 0;
}
bool Proyectil::Impacto(Asteroide* ast)const{
    float X1= 0 , Y1 = -2;
    float X2= 0 , Y2 = 2;
    Rotacion(X1,Y1,0,0,A);
    Rotacion(X2,Y2,0,0,A);
    return ast->DentroDe(X1+Cx,Y1+Cy) || ast->DentroDe(X2+Cx,Y2+Cy);
}
void Fragmentos::Construir(BITMAP *buffer)const{
    float X1= 0 , Y1 = -4;
    float X2= 0 , Y2 = 4;
    Rotacion(X1,Y1,0,0,A);
    Rotacion(X2,Y2,0,0,A);
    line(buffer,X1+Cx,Y1+Cy,X2+Cx,Y2+Cy,0xEAECEE);
}
void Fragmentos::Desplazamiento(){
    Cx += Vx;
    Cy += Vy;
    A+=4;
}
bool Fragmentos::Fuera()const{
    return Cx > XTAM || Cx < 0 || Cy > YTAM || Cy < 0;
}

Fragmentos::Fragmentos(float _x,float _y,float _a):Objeto(_x,_y){
    //A = _a;
    A=Azar(360);
    Vx=Azar(2.0)-1.0; Vy=Azar(2.0)-1.0;
    Rotacion(Vx,Vy,0,0,A);
}
Fragmentos *Nave::Explosion(BITMAP*buffer,float a){
           float X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5;
           Vertices(X1,Y1,X2,Y2,X3,Y3,X4,Y4,X5,Y5);

    return new Fragmentos(X5,Y5,A);


    /*float dx1,dy1;
    //dx1 += X5;
    //dy1 += Y5;
    //Base
    //Cx += Vx;
    //Cy += Vy;

    Rotacion(X1,Y1,X2,Y2,a);
    //Rotacion(X2,Y2,Cx,Cy,a);
    Rotacion(X3,Y3,X5,Y5,a);
    //Rotacion(X4,Y4,Cx,Cy,a);
    Rotacion(X4,Y4,X5,Y5,a);

    line(buffer,X1,Y1,X2,Y2,0xEAECEE);
    line(buffer,X3,Y3,X5,Y5,0xEAECEE);
    line(buffer,X4,Y4,X5,Y5,0xEAECEE);*/


}
