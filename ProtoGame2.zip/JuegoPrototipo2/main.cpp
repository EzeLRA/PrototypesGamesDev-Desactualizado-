#include <iostream>
#include <cstdlib>
#include <allegro.h>
#include <list>
#include <sstream>

#include "inicia.h" //Genera el entorno grafico o ventana
#include "Objetos.h"
#include "Funciones.h"
using namespace std;


class Juego{
    Nave N;
    list<Fragmentos*> F;
    list<Asteroide*> A;
    list<Proyectil*> M;

public:
    Juego();
    void Desplazamiento(BITMAP *buffer);
    bool Colisiones(BITMAP *buffer);

    int MenuTeclas();
    void Estadisticas(BITMAP *buffer,int naves,int p);
    void InicioTitulo(BITMAP *buffer);

    void ConstruirNave(BITMAP *buffer);
    bool ColisionEnNave();
    void ExplosionNave(BITMAP *buffer,float a);
    void ReaparicionNave(float _x,float _y);

    void ReaparicionAsteroides(BITMAP *buffer);
};

Juego::Juego():N(XTAM/2,YTAM/2)
{
    list<Fragmentos*>::iterator Itd;
    list<Asteroide*>::iterator It;
    list<Proyectil*>::iterator Itm;
    for(int i=0;i<8;i++){
        A.push_back(new Asteroide());
    }
}
void Juego::ConstruirNave(BITMAP *buffer){
    N.Desplazamiento();
    N.Construir(buffer);


    if(key[KEY_UP]){
        N.Acelerar();
        N.Fuego(buffer);
    }
    if(key[KEY_LEFT]){
        N.Rotar(5);
    }
    if(key[KEY_RIGHT]){
        N.Rotar(-5);
    }
    if(key[KEY_SPACE]){
        M.push_back(N.Disparo(buffer));
    }
}

bool Juego::ColisionEnNave(){
    for(auto It =A.begin();It != A.end();It++){
    if(N.Colision(*It)){

    return true;
   }
}
}


void Juego::Desplazamiento(BITMAP *buffer){


    for(auto It =A.begin();It != A.end();It++){
        (*It)->Desplazamiento();
    }
    for(auto It =A.begin();It != A.end();It++){
        (*It)->Construir(buffer);
    }

    for(auto Itm =M.begin();Itm != M.end();Itm++){
        (*Itm)->Desplazamiento();
    }
    for(auto Itm =M.begin();Itm != M.end();Itm++){
        (*Itm)->Construir(buffer);
    }

    for(auto Itd =F.begin();Itd != F.end();Itd++){
        (*Itd)->Desplazamiento();
    }
    for(auto Itd =F.begin();Itd != F.end();Itd++){
        (*Itd)->Construir(buffer);
    }

    auto Itm = M.begin();
    while(Itm != M.end()){
        if ((*Itm)->Fuera()){
            delete(*Itm);
            Itm = M.erase(Itm);
        }else{
            Itm++;
        }
    }

    auto Itd = F.begin();
    while(Itd != F.end()){
        if ((*Itd)->Fuera()){
            delete(*Itd);
            Itd = F.erase(Itd);
        }else{
            Itd++;
        }
    }




}
bool Juego::Colisiones(BITMAP *buffer){

        auto Itm = M.begin();

        while(Itm != M.end()){
        auto It = A.begin();

            while(It!=A.end() && !(*Itm)->Impacto(*It)){
                It++;
            }
            if(It != A.end()){
                (*It)->Explota(A);
                delete *It;
                It = A.erase(It);
                delete *Itm;
                Itm = M.erase(Itm);
                return true;
            }else{
                Itm++;
            }

        }


    }


int Juego::MenuTeclas(){
    int TecPres=0;
    if(key[KEY_ENTER]){
    TecPres=1;
    if(!key[KEY_ENTER]&&TecPres==1){
        return TecPres=1;
    }
    }
}

void Juego::InicioTitulo(BITMAP *buffer){
    //line(buffer,150,200,369,200,0xEAECEE);
    textout_centre_ex(buffer,font,"Asteroids",XTAM/2,120,0xEAECEE,0x000000);


    textout_centre_ex(buffer,font,"Presione (Enter) para Iniciar",XTAM/2,150,0xEAECEE,0x000000);
    textout_centre_ex(buffer,font,"Controles:",XTAM/2,200,0xEAECEE,0x000000);
    textout_centre_ex(buffer,font,"(Arriba)Avanzar",XTAM/2,220,0xEAECEE,0x000000);
    textout_centre_ex(buffer,font,"(Izquierda)Rotar (Derecha)Rotar",XTAM/2,240,0xEAECEE,0x000000);
    textout_centre_ex(buffer,font,"(Espacio)Disparar",XTAM/2,260,0xEAECEE,0x000000);
    textout_centre_ex(buffer,font,"(R)Reiniciar o reaparecer",XTAM/2,280,0xEAECEE,0x000000);

    textout_centre_ex(buffer,font,"(Escape)Cerrar el juego",XTAM/2,320,0xEAECEE,0x000000);

}

void Juego::ExplosionNave(BITMAP *buffer,float a){
        F.push_back(N.Explosion(buffer,a));
}
void Juego::ReaparicionNave(float _x,float _y){
    N.Reaparicion(_x,_y);

    auto Itd = F.begin();
    while(Itd != F.end()){
        if (key[KEY_R]){
            delete(*Itd);
            Itd = F.erase(Itd);
        }else{
            Itd++;
        }
    }
}
void Juego::ReaparicionAsteroides(BITMAP *buffer){
    auto It = A.begin();
    if(It == A.end()){
    for(int i=0;i<8;i++){
        A.push_back(new Asteroide());
    }
    }
}

void Juego::Estadisticas(BITMAP *buffer,int naves,int p){

    textprintf(buffer,font,XTAM-490,YTAM-500,0xEAECEE,"Asteroides: %d",A.size());
    textprintf(buffer,font,XTAM-370,YTAM-500,0xEAECEE,"Naves: %d",N.NavesDisponibles(naves));
    textprintf(buffer,font,XTAM-170,YTAM-500,0xEAECEE,"Puntos: %d",N.PuntosDisponibles(p));

    //textprintf(buffer,font,XTAM-370,YTAM-500,0xEAECEE,"Asteroides: %d  Puntos: X  Naves: X Misiles: %d",A.size(),M.size());
    //textout_centre_ex(buffer,font,"Asteroides: X  Puntos: X  Naves: X",XTAM-370,YTAM-500,0xEAECEE,0x000000);
}


int main ()
{

    Juego J;

    srand(time(0));
    inicia_allegro(XTAM,YTAM);



    BITMAP *buffer = create_bitmap(XTAM,YTAM);
    int naves=0;
    int p=0;

    while(!key[KEY_ESC]&&!key[KEY_ENTER]&&naves==0){
      clear_to_color(buffer, 0x000000);



      J.Desplazamiento(buffer);
        J.InicioTitulo(buffer);

      blit(buffer, screen, 0, 0, 0, 0, XTAM, YTAM);
      rest(20);
    }
    naves = 3;


    while(!key[KEY_ESC]){
    clear_to_color(buffer, 0x000000);



    J.Desplazamiento(buffer);
    J.ConstruirNave(buffer);

    J.Colisiones(buffer);
    J.ReaparicionAsteroides(buffer);

    //J.Colisiones(buffer);
    if(J.Colisiones(buffer)==true){
        p +=50;
    }
    J.Estadisticas(buffer,naves,p);


    if(J.ColisionEnNave()==true){//Menu de Explosion y Reinicio
    naves--;
        for(int i=0;i<4;i++){
        J.ExplosionNave(buffer,i);
        }

        if(naves==0){
        do{
    clear_bitmap(buffer);

    J.Desplazamiento(buffer);
    textout_centre_ex(buffer,font,"Has perdido",XTAM/2,YTAM/2,0xEAECEE,0x000000);
    textout_centre_ex(buffer,font,"Presione R para Reiniciar",XTAM/2,YTAM-240,0xEAECEE,0x000000);
    //Mostrar puntos :

    blit(buffer, screen, 0, 0, 0, 0, XTAM, YTAM);
    rest(20);

    if(key[KEY_R]){//Reaparicion de la nave
        naves = 3;
        p=0;
        J.ReaparicionNave(XTAM/2,YTAM/2);
        break;
    }

    }while(!key[KEY_ESC]);

        }


        do{
    clear_bitmap(buffer);

    J.Desplazamiento(buffer);
    textout_centre_ex(buffer,font,"Has colisionado",XTAM/2,YTAM/2,0xEAECEE,0x000000);
    textout_centre_ex(buffer,font,"Presione R para continuar",XTAM/2,YTAM-240,0xEAECEE,0x000000);


    blit(buffer, screen, 0, 0, 0, 0, XTAM, YTAM);
    rest(20);

    if(key[KEY_R]){//Reaparicion de la nave
        J.ReaparicionNave(XTAM/2,YTAM/2);
        break;
    }

    }while(!key[KEY_ESC]);

}



    blit(buffer, screen, 0, 0, 0, 0, XTAM, YTAM);
    rest(20);
    }
    destroy_bitmap(buffer);



    return 0;
}
END_OF_MAIN ()
