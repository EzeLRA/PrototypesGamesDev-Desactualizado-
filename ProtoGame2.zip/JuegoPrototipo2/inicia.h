#ifndef INICIA_H_INCLUDED
#define INICIA_H_INCLUDED

void inicia_allegro(int ANCHO_ , int ALTO_);


#endif // INICIA_H_INCLUDED
