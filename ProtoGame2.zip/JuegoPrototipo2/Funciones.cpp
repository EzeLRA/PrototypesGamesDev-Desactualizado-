#include <cmath>
#include <cstdlib>
using namespace std;

#include "Funciones.h"

void Rotacion(float &x,float &y,float Cx,float Cy,float da){
    float dx = x - Cx;
    float dy = y - Cy;
    float r = sqrt(dx*dx + dy*dy);
    float a = atan2(dy,dx);

    float da_rad = da/180 * M_PI;
    a -= da_rad;
    x = Cx + r*cos(a);
    y = Cy + r*sin(a);
}

void Limites(float &l,float Lim){
    if(l>Lim){
        l-=Lim;
    }if(l<0){
        l+=Lim;
    }
}

float Azar(float Maximo){
    return Maximo*(float(rand())/float(RAND_MAX));
}
