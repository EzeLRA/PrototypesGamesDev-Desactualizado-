#ifndef OBJETOS_H
#define OBJETOS_H
#include <list>
#include <vector>

const float XTAM=520 , YTAM=520 ;

class Objeto{
protected:
    float Cx,Cy,A,Vx,Vy;
public:
    Objeto(float _X,float _Y);
    void Desplazamiento();
    void Rotar(double da);
    void Acelerar();

};

class Asteroide : public Objeto{
    float Tamanio;
    std::vector<float> x,y;
    void puntos();

public:
    Asteroide();
    Asteroide(float _x,float _y,float _tam,float _vx,float _vy);
    void Construir(BITMAP *buffer) const;
    bool DentroDe(float _x,float _y)const;
    void Explota(std::list<Asteroide*>&A)const;
};

class Proyectil : public Objeto{
public:
    Proyectil(float _x,float _y,float _a);
    void Construir(BITMAP *buffer) const;
    void Desplazamiento();
    bool Fuera()const;
    bool Impacto(Asteroide *A)const;
};

class Fragmentos : public Objeto{
public:
    Fragmentos(float _x,float _y,float _a);
    void Construir(BITMAP *buffer) const;
    void Desplazamiento();
    bool Fuera()const;
};

class Nave : public Objeto{
    int Naves;
    int Puntos;
    void Vertices(float& X1,float& Y1,
                  float& X2,float& Y2,
                  float& X3,float& Y3,
                  float& X4,float& Y4,
                  float& X5,float& Y5) const;

public:
    Nave(float _X,float _Y):Objeto(_X,_Y){}
    void Construir(BITMAP *buffer) const;
    bool Colision(Asteroide* A) const;
    Fragmentos *Explosion(BITMAP *buffer,float a);
    Proyectil *Disparo(BITMAP *buffer)const;
    void Reaparicion(float x,float y);
    void Fuego(BITMAP *buffer) const;
    int NavesDisponibles(int Naves);
    int PuntosDisponibles(int p);
};



#endif // OBJETOS_H
