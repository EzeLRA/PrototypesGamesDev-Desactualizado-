#ifndef FUNCIONES_H
#define FUNCIONES_H

void Rotacion(float &x,float &y,float Cx,float Cy,float da);
void Limites(float &l,float Lim);
float Azar(float Maximo);

#endif // FUNCIONES_
